<?php

    $version = '1.6.0' ;

?>
