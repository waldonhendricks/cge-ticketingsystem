# MaterialOs--Theme-for-OsTicket-v1.10.1
MaterialOs- Theme with Material Kit for OsTicket v1.10.1

# Status
- Currently Under Construction

# Working
- Responsive adaptation
- General adaptation of each section
